def f():

    count = "{:.2f}".format(3 / 1e6)
    return count    