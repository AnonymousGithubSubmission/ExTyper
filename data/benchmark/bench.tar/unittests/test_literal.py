def f(x):
    return 0


f('1')