def f(x):
    return x + 1

# def g(x):
#     return [x]

    
