def f(a,b,c,d,e,f,g):
    return a + 1   


def g():
    return f(1,1,1,1,1,1,1,)

