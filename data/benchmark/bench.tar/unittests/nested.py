def f(x):
    
    def g():
        return 1 + x

    return g()

