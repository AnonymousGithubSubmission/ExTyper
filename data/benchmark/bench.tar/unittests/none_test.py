def f():
    try:
        x = 1 + '1'
    except Exception:
        return None
    return 1


# def g():
