def f():
    a = []
    a.append(1)

    return a