
def f1(x):
    u = x[0]
    v = x * 3
    return v * u
