a = [1,2,3]

def f():
    return a