def f():
    return "%d" % 1