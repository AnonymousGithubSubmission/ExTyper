import os
peer_hostnames= {p for p in os.environ.get('TC_PEERS', '').split(',') if p}

def f():
    return peer_hostnames