def f():
    return lambda y: y.fidelity