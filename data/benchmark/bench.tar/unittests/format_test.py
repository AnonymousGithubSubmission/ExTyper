
def decode(x:str)->str:...

def f(number):
    ord = 1
    return decode("{}{}".format(number, ord))