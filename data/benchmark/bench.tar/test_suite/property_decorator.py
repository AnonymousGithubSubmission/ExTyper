class A:
    # Edit: property
    # @property
    def x(self):
        return 1

a = A().x() + 1

# a := int