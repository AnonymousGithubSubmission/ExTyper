class A(object):
    def something(self):
        return 3