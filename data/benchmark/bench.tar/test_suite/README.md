This is from the unittests of TYPPETE (CAV18: MaxSMT-Based Type Inference for Python 3)

Since STRAY only recommend for functions, we exclude the unittests without any function. 