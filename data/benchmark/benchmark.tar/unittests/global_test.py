a = 1


def f(x):
    y = x + 1
    return y