def f(x):
    return x or 1