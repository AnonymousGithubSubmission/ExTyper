from typing import Dict


# class A:
#     D:Dict[int,int]


#     def f(self, x):
#         y = self.D.get(1)

#         return y or x



D:Dict[int,int]


def f(x):
    y = D.get(1)

    return y or x

