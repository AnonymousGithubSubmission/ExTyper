def f(x=None):
    return x + 1