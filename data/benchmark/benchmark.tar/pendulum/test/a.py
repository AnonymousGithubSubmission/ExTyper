def f(a,b,c):
    p = a+b
    s = sorted(p,c)
    return s
