from typing import Dict


def dump(d: Dict[str, object]) -> str:
    ...