from typing import Tuple, List

def unpack(fmt: str, buffer: bytes) -> List[object]:
    ...

def pack(fmt: str, o: object) -> bytes:
    ...